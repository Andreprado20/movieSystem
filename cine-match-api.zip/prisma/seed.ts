import { PrismaClient } from "@prisma/client"
import * as bcrypt from "bcrypt"

const prisma = new PrismaClient()

async function main() {
  console.log("Seeding database...")

  // Create some genres
  const genres = await Promise.all([
    prisma.genre.upsert({
      where: { name: "Action" },
      update: {},
      create: { name: "Action" },
    }),
    prisma.genre.upsert({
      where: { name: "Comedy" },
      update: {},
      create: { name: "Comedy" },
    }),
    prisma.genre.upsert({
      where: { name: "Drama" },
      update: {},
      create: { name: "Drama" },
    }),
    prisma.genre.upsert({
      where: { name: "Science Fiction" },
      update: {},
      create: { name: "Science Fiction" },
    }),
    prisma.genre.upsert({
      where: { name: "Thriller" },
      update: {},
      create: { name: "Thriller" },
    }),
  ])

  // Create some users
  const hashedPassword = await bcrypt.hash("password123", 10)

  const alice = await prisma.user.upsert({
    where: { email: "alice@example.com" },
    update: {},
    create: {
      email: "alice@example.com",
      username: "alice",
      name: "Alice Johnson",
      password: hashedPassword,
      birthDate: new Date("1990-01-01"),
      bio: "Movie enthusiast",
      notificationSettings: {
        create: {},
      },
      privacySettings: {
        create: {},
      },
    },
  })

  const bob = await prisma.user.upsert({
    where: { email: "bob@example.com" },
    update: {},
    create: {
      email: "bob@example.com",
      username: "bob",
      name: "Bob Smith",
      password: hashedPassword,
      birthDate: new Date("1985-05-15"),
      bio: "Sci-fi lover",
      notificationSettings: {
        create: {},
      },
      privacySettings: {
        create: {},
      },
    },
  })

  // Create some movies
  const movie1 = await prisma.movie.upsert({
    where: { tmdbId: 1 },
    update: {},
    create: {
      tmdbId: 1,
      title: "Inception",
      overview: "A thief who steals corporate secrets through the use of dream-sharing technology.",
      posterPath: "/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg",
      backdropPath: "/s3TBrRGB1iav7gFOCNx3H31MoES.jpg",
      releaseDate: new Date("2010-07-16"),
      runtime: 148,
      voteAverage: 8.3,
      voteCount: 30000,
      genres: {
        create: [
          { genre: { connect: { id: genres[0].id } } }, // Action
          { genre: { connect: { id: genres[3].id } } }, // Sci-Fi
        ],
      },
    },
  })

  const movie2 = await prisma.movie.upsert({
    where: { tmdbId: 2 },
    update: {},
    create: {
      tmdbId: 2,
      title: "The Shawshank Redemption",
      overview:
        "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
      posterPath: "/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg",
      backdropPath: "/kXfqcdQKsToO0OUXHcrrNCHDBzO.jpg",
      releaseDate: new Date("1994-09-23"),
      runtime: 142,
      voteAverage: 8.7,
      voteCount: 25000,
      genres: {
        create: [
          { genre: { connect: { id: genres[2].id } } }, // Drama
        ],
      },
    },
  })

  // Create some reviews
  const review1 = await prisma.review.create({
    data: {
      content: "One of the best movies I have ever seen!",
      rating: 10,
      userId: alice.id,
      movieId: movie1.id,
    },
  })

  const review2 = await prisma.review.create({
    data: {
      content: "A classic that never gets old.",
      rating: 9,
      userId: bob.id,
      movieId: movie2.id,
    },
  })

  // Create some comments
  await prisma.comment.create({
    data: {
      content: "I totally agree with you!",
      userId: bob.id,
      reviewId: review1.id,
    },
  })

  await prisma.comment.create({
    data: {
      content: "One of my favorites too.",
      userId: alice.id,
      reviewId: review2.id,
    },
  })

  // Create some likes
  await prisma.reviewLike.create({
    data: {
      userId: bob.id,
      reviewId: review1.id,
    },
  })

  await prisma.reviewLike.create({
    data: {
      userId: alice.id,
      reviewId: review2.id,
    },
  })

  // Create user movie relationships
  await prisma.watchedMovie.create({
    data: {
      userId: alice.id,
      movieId: movie1.id,
    },
  })

  await prisma.favoriteMovie.create({
    data: {
      userId: alice.id,
      movieId: movie1.id,
    },
  })

  await prisma.watchLaterMovie.create({
    data: {
      userId: bob.id,
      movieId: movie1.id,
    },
  })

  // Create a community
  const community = await prisma.community.create({
    data: {
      name: "Sci-Fi Enthusiasts",
      description: "A community for science fiction movie lovers.",
      ownerId: alice.id,
      members: {
        create: [{ userId: alice.id, role: "admin" }, { userId: bob.id }],
      },
      movies: {
        create: [{ movieId: movie1.id }],
      },
    },
  })

  // Create an event
  await prisma.event.create({
    data: {
      title: "Inception Movie Night",
      description: "Let's watch Inception together!",
      date: new Date("2023-12-15T20:00:00Z"),
      type: "watchparty",
      movieId: movie1.id,
      communityId: community.id,
      creatorId: alice.id,
      participants: {
        create: [
          { userId: alice.id, status: "going" },
          { userId: bob.id, status: "maybe" },
        ],
      },
    },
  })

  // Create a conversation
  const conversation = await prisma.conversation.create({
    data: {
      isGroup: false,
      participants: {
        create: [{ userId: alice.id }, { userId: bob.id }],
      },
    },
  })

  // Create some messages
  await prisma.message.create({
    data: {
      content: "Hey Bob! Did you watch Inception?",
      userId: alice.id,
      conversationId: conversation.id,
      readBy: {
        create: [{ userId: alice.id }],
      },
    },
  })

  await prisma.message.create({
    data: {
      content: "Not yet, but it's on my watchlist!",
      userId: bob.id,
      conversationId: conversation.id,
      readBy: {
        create: [{ userId: alice.id }, { userId: bob.id }],
      },
    },
  })

  // Create some notifications
  await prisma.notification.create({
    data: {
      type: "follow",
      content: "Bob started following you.",
      receiverId: alice.id,
      entityId: bob.id,
      entityType: "user",
    },
  })

  await prisma.notification.create({
    data: {
      type: "like",
      content: "Alice liked your review of The Shawshank Redemption.",
      receiverId: bob.id,
      entityId: review2.id,
      entityType: "review",
    },
  })

  // Create social connections
  await prisma.follow.create({
    data: {
      followerId: bob.id,
      followingId: alice.id,
    },
  })

  // Create a list
  await prisma.list.create({
    data: {
      name: "Must-Watch Sci-Fi",
      description: "My collection of must-watch science fiction movies.",
      userId: alice.id,
      items: {
        create: [{ movieId: movie1.id, order: 1 }],
      },
    },
  })

  console.log("Database has been seeded!")
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })

# CineMatch API

A comprehensive REST API for the CineMatch social movie platform built with NestJS and Prisma.

## Features

- Complete authentication system with JWT
- User profiles and social features
- Movie database with detailed information
- Reviews, ratings, and comments
- Movie collections (watched, favorites, watch later)
- Communities and groups
- Events and calendar
- Real-time chat and messaging
- Notifications
- Custom lists and collections
- Advanced search and discovery

## Tech Stack

- **Framework**: NestJS
- **Database ORM**: Prisma
- **Database**: PostgreSQL
- **Authentication**: JWT
- **Documentation**: Swagger/OpenAPI
- **Validation**: class-validator
- **Testing**: Jest

## Getting Started

### Prerequisites

- Node.js (v16+)
- npm or yarn
- PostgreSQL database

### Installation

1. Clone the repository:
   \`\`\`bash
   git clone https://github.com/your-username/cine-match-api.git
   cd cine-match-api
   \`\`\`

2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Set up environment variables:
   Create a `.env` file in the root directory with the following variables:
   \`\`\`
   DATABASE_URL="postgresql://username:password@localhost:5432/cinematch?schema=public"
   JWT_SECRET="your-secret-key"
   JWT_EXPIRES_IN="1d"
   \`\`\`

4. Run database migrations:
   \`\`\`bash
   npx prisma migrate dev
   \`\`\`

5. Seed the database (optional):
   \`\`\`bash
   npx prisma db seed
   \`\`\`

6. Start the development server:
   \`\`\`bash
   npm run start:dev
   \`\`\`

The API will be available at `http://localhost:3000`.
API documentation will be available at `http://localhost:3000/api-docs`.

## API Structure

The API is structured into the following modules:

- **Auth**: User registration, login, and token management
- **Users**: User profiles and settings
- **Movies**: Movie information and user actions
- **Reviews**: Movie reviews, ratings, likes, and comments
- **Communities**: Social groups for movie enthusiasts
- **Events**: Movie-related events and watchparties
- **Messaging**: Conversations and real-time chat
- **Notifications**: User notifications
- **Lists**: Custom movie collections

## Docker Deployment

1. Build the Docker image:
   \`\`\`bash
   docker build -t cinematch-api .
   \`\`\`

2. Run the container:
   \`\`\`bash
   docker run -p 3000:3000 --env-file .env cinematch-api
   \`\`\`

## License

This project is licensed under the MIT License - see the LICENSE file for details.

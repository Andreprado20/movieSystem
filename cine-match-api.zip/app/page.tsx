import Link from "next/link"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-black text-white p-6">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">CineMatch API</h1>
          <nav>
            <ul className="flex space-x-4">
              <li>
                <Link href="/api" className="hover:text-pink-400 transition-colors">
                  API Docs
                </Link>
              </li>
              <li>
                <Link
                  href="https://github.com/your-username/cine-match-api"
                  className="hover:text-pink-400 transition-colors"
                >
                  GitHub
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="flex-grow container mx-auto px-6 py-12">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">CineMatch API Documentation</h2>
          <p className="text-xl mb-8">A comprehensive REST API for the CineMatch social movie platform.</p>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-12">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-bold mb-2">Authentication</h3>
              <p className="mb-4">Secure user authentication with JWT tokens</p>
              <Link href="/api#auth" className="text-pink-600 hover:text-pink-800">
                Learn more →
              </Link>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-bold mb-2">Movies</h3>
              <p className="mb-4">Access movie data and user interactions</p>
              <Link href="/api#movies" className="text-pink-600 hover:text-pink-800">
                Learn more →
              </Link>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-bold mb-2">Social</h3>
              <p className="mb-4">Communities, messaging, and social features</p>
              <Link href="/api#social" className="text-pink-600 hover:text-pink-800">
                Learn more →
              </Link>
            </div>
          </div>

          <Link
            href="/api"
            className="inline-block bg-pink-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-pink-700 transition-colors"
          >
            View Complete Documentation
          </Link>
        </div>
      </main>

      <footer className="bg-gray-100 p-6">
        <div className="container mx-auto text-center">
          <p>© {new Date().getFullYear()} CineMatch API. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

import { Controller, Get, Post, Delete, Param, Query, UseGuards, Req, Body } from "@nestjs/common"
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery, ApiParam } from "@nestjs/swagger"
import type { MoviesService } from "./movies.service"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import type { Request } from "express"
import type { MovieIdDto } from "./dto/movie-id.dto"

@ApiTags("movies")
@Controller("filmes")
export class MoviesController {
  constructor(private readonly moviesService: MoviesService) {}

  @Get()
  @ApiOperation({ summary: "Get list of movies" })
  @ApiQuery({ name: "page", required: false, type: Number })
  @ApiQuery({ name: "limit", required: false, type: Number })
  @ApiQuery({ name: "sort", required: false, enum: ["popularity", "rating", "release_date", "title"] })
  @ApiQuery({ name: "genre", required: false, type: String })
  @ApiResponse({ status: 200, description: "Return a list of movies." })
  findAll(
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('sort') sort?: string,
    @Query('genre') genre?: string,
  ): Promise<any> {
    return this.moviesService.findAll({ page, limit, sort, genre })
  }

  @Get("genres")
  @ApiOperation({ summary: "Get all movie genres" })
  @ApiResponse({ status: 200, description: "Return a list of genres." })
  getAllGenres() {
    return this.moviesService.getAllGenres()
  }

  @Get("trending")
  @ApiOperation({ summary: "Get trending movies" })
  @ApiQuery({ name: "timeWindow", required: false, enum: ["day", "week"] })
  @ApiQuery({ name: "limit", required: false, type: Number })
  @ApiResponse({ status: 200, description: "Return a list of trending movies." })
  getTrendingMovies(@Query('timeWindow') timeWindow?: string, @Query('limit') limit?: number) {
    return this.moviesService.getTrendingMovies({ timeWindow, limit })
  }

  @Get("recommendations")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: "Get personalized recommendations" })
  @ApiQuery({ name: "limit", required: false, type: Number })
  @ApiResponse({ status: 200, description: "Return a list of recommended movies." })
  getRecommendations(@Req() req: Request, @Query('limit') limit?: number) {
    return this.moviesService.getRecommendations(req.user["id"], limit)
  }

  @Get(':id')
  @ApiParam({ name: 'id', description: 'Movie ID' })
  @ApiOperation({ summary: 'Get movie details' })
  @ApiResponse({ status: 200, description: 'Return the movie details.' })
  @ApiResponse({ status: 404, description: 'Movie not found.' })
  findOne(@Param('id') id: string) {
    return this.moviesService.findOne(id);
  }

  @Get(":id/reviews")
  @ApiParam({ name: "id", description: "Movie ID" })
  @ApiOperation({ summary: "Get movie reviews" })
  @ApiQuery({ name: "page", required: false, type: Number })
  @ApiQuery({ name: "limit", required: false, type: Number })
  @ApiResponse({ status: 200, description: "Return a list of reviews for the movie." })
  @ApiResponse({ status: 404, description: "Movie not found." })
  getReviews(@Param('id') id: string, @Query('page') page?: number, @Query('limit') limit?: number) {
    return this.moviesService.getReviews(id, { page, limit })
  }

  @Get(":id/similar")
  @ApiParam({ name: "id", description: "Movie ID" })
  @ApiOperation({ summary: "Get similar movies" })
  @ApiQuery({ name: "limit", required: false, type: Number })
  @ApiResponse({ status: 200, description: "Return a list of similar movies." })
  @ApiResponse({ status: 404, description: "Movie not found." })
  getSimilarMovies(@Param('id') id: string, @Query('limit') limit?: number) {
    return this.moviesService.getSimilarMovies(id, limit)
  }

  @Post("me/movies/watched")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: "Mark movie as watched" })
  @ApiResponse({ status: 200, description: "Movie marked as watched." })
  @ApiResponse({ status: 404, description: "Movie not found." })
  markAsWatched(@Req() req: Request, @Body() movieIdDto: MovieIdDto) {
    return this.moviesService.markAsWatched(req.user["id"], movieIdDto.movieId)
  }

  @Delete("me/movies/watched/:movieId")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "movieId", description: "Movie ID" })
  @ApiOperation({ summary: "Remove movie from watched" })
  @ApiResponse({ status: 200, description: "Movie removed from watched list." })
  @ApiResponse({ status: 404, description: "Movie not found." })
  removeFromWatched(@Req() req: Request, @Param('movieId') movieId: string) {
    return this.moviesService.removeFromWatched(req.user["id"], movieId)
  }

  @Post("me/movies/favorites")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: "Add movie to favorites" })
  @ApiResponse({ status: 200, description: "Movie added to favorites." })
  @ApiResponse({ status: 404, description: "Movie not found." })
  addToFavorites(@Req() req: Request, @Body() movieIdDto: MovieIdDto) {
    return this.moviesService.addToFavorites(req.user["id"], movieIdDto.movieId)
  }

  @Delete("me/movies/favorites/:movieId")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "movieId", description: "Movie ID" })
  @ApiOperation({ summary: "Remove movie from favorites" })
  @ApiResponse({ status: 200, description: "Movie removed from favorites." })
  @ApiResponse({ status: 404, description: "Movie not found." })
  removeFromFavorites(@Req() req: Request, @Param('movieId') movieId: string) {
    return this.moviesService.removeFromFavorites(req.user["id"], movieId)
  }

  @Post("me/movies/watchlater")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: "Add movie to watch later" })
  @ApiResponse({ status: 200, description: "Movie added to watch later list." })
  @ApiResponse({ status: 404, description: "Movie not found." })
  addToWatchLater(@Req() req: Request, @Body() movieIdDto: MovieIdDto) {
    return this.moviesService.addToWatchLater(req.user["id"], movieIdDto.movieId)
  }

  @Delete("me/movies/watchlater/:movieId")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "movieId", description: "Movie ID" })
  @ApiOperation({ summary: "Remove from watch later" })
  @ApiResponse({ status: 200, description: "Movie removed from watch later list." })
  @ApiResponse({ status: 404, description: "Movie not found." })
  removeFromWatchLater(@Req() req: Request, @Param('movieId') movieId: string) {
    return this.moviesService.removeFromWatchLater(req.user["id"], movieId)
  }

  @Get("users/:id/movies/watched")
  @ApiParam({ name: "id", description: "User ID" })
  @ApiOperation({ summary: "Get user's watched movies" })
  @ApiQuery({ name: "page", required: false, type: Number })
  @ApiQuery({ name: "limit", required: false, type: Number })
  @ApiResponse({ status: 200, description: "Return a list of watched movies." })
  getUserWatchedMovies(@Param('id') id: string, @Query('page') page?: number, @Query('limit') limit?: number) {
    return this.moviesService.getUserWatchedMovies(id, { page, limit })
  }

  @Get("users/:id/movies/favorites")
  @ApiParam({ name: "id", description: "User ID" })
  @ApiOperation({ summary: "Get user's favorite movies" })
  @ApiQuery({ name: "page", required: false, type: Number })
  @ApiQuery({ name: "limit", required: false, type: Number })
  @ApiResponse({ status: 200, description: "Return a list of favorite movies." })
  getUserFavoriteMovies(@Param('id') id: string, @Query('page') page?: number, @Query('limit') limit?: number) {
    return this.moviesService.getUserFavoriteMovies(id, { page, limit })
  }

  @Get("users/:id/movies/watchlater")
  @ApiParam({ name: "id", description: "User ID" })
  @ApiOperation({ summary: "Get user's watch later list" })
  @ApiQuery({ name: "page", required: false, type: Number })
  @ApiQuery({ name: "limit", required: false, type: Number })
  @ApiResponse({ status: 200, description: "Return a list of watch later movies." })
  getUserWatchLaterMovies(@Param('id') id: string, @Query('page') page?: number, @Query('limit') limit?: number) {
    return this.moviesService.getUserWatchLaterMovies(id, { page, limit })
  }
}

import { Injectable, NotFoundException, BadRequestException } from "@nestjs/common"
import type { PrismaService } from "../prisma/prisma.service"

@Injectable()
export class MoviesService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(query: {
    page?: number
    limit?: number
    sort?: string
    genre?: string
  }) {
    const { page = 1, limit = 20, sort = "popularity", genre } = query
    const skip = (page - 1) * limit

    // Build where condition
    const where = genre
      ? {
          genres: {
            some: {
              genre: {
                name: {
                  equals: genre,
                  mode: "insensitive",
                },
              },
            },
          },
        }
      : {}

    // Build orderBy condition
    let orderBy = {}
    switch (sort) {
      case "popularity":
        orderBy = { voteCount: "desc" }
        break
      case "rating":
        orderBy = { voteAverage: "desc" }
        break
      case "release_date":
        orderBy = { releaseDate: "desc" }
        break
      case "title":
        orderBy = { title: "asc" }
        break
      default:
        orderBy = { voteCount: "desc" }
        break
    }

    const [movies, totalCount] = await Promise.all([
      this.prisma.movie.findMany({
        where,
        orderBy,
        skip,
        take: limit,
        include: {
          genres: {
            include: {
              genre: true,
            },
          },
        },
      }),
      this.prisma.movie.count({ where }),
    ])

    return {
      data: movies.map((movie) => ({
        ...movie,
        genres: movie.genres.map((mg) => mg.genre.name),
      })),
      meta: {
        current_page: page,
        per_page: limit,
        total_count: totalCount,
        total_pages: Math.ceil(totalCount / limit),
      },
    }
  }

  async findOne(id: string) {
    const movie = await this.prisma.movie.findUnique({
      where: { id },
      include: {
        genres: {
          include: {
            genre: true,
          },
        },
      },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${id} not found`)
    }

    return {
      ...movie,
      genres: movie.genres.map((mg) => mg.genre.name),
    }
  }

  async getReviews(id: string, query: { page?: number; limit?: number }) {
    const { page = 1, limit = 20 } = query
    const skip = (page - 1) * limit

    // Check if movie exists
    const movie = await this.prisma.movie.findUnique({
      where: { id },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${id} not found`)
    }

    const [reviews, totalCount] = await Promise.all([
      this.prisma.review.findMany({
        where: { movieId: id },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
        include: {
          user: {
            select: {
              id: true,
              username: true,
              name: true,
              avatar: true,
            },
          },
          _count: {
            select: {
              likes: true,
              comments: true,
            },
          },
        },
      }),
      this.prisma.review.count({ where: { movieId: id } }),
    ])

    return {
      data: reviews.map((review) => ({
        ...review,
        likesCount: review._count.likes,
        commentsCount: review._count.comments,
        _count: undefined,
      })),
      meta: {
        current_page: page,
        per_page: limit,
        total_count: totalCount,
        total_pages: Math.ceil(totalCount / limit),
      },
    }
  }

  async getSimilarMovies(id: string, limit = 10) {
    // Check if movie exists
    const movie = await this.prisma.movie.findUnique({
      where: { id },
      include: {
        genres: {
          include: {
            genre: true,
          },
        },
      },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${id} not found`)
    }

    // Get genre IDs
    const genreIds = movie.genres.map((g) => g.genreId)

    // Find similar movies (same genres, but not the same movie)
    const similarMovies = await this.prisma.movie.findMany({
      where: {
        id: { not: id },
        genres: {
          some: {
            genreId: { in: genreIds },
          },
        },
      },
      include: {
        genres: {
          include: {
            genre: true,
          },
        },
      },
      take: limit,
    })

    return similarMovies.map((movie) => ({
      ...movie,
      genres: movie.genres.map((mg) => mg.genre.name),
    }))
  }

  async getAllGenres() {
    const genres = await this.prisma.genre.findMany({
      orderBy: { name: "asc" },
    })

    return genres
  }

  async getTrendingMovies(query: { timeWindow?: string; limit?: number }) {
    const { timeWindow = "day", limit = 10 } = query

    // For demonstration, we'll just sort by vote count
    // In a real application, you would have a more sophisticated algorithm
    const orderBy = { voteCount: "desc" }

    const trendingMovies = await this.prisma.movie.findMany({
      orderBy,
      take: limit,
      include: {
        genres: {
          include: {
            genre: true,
          },
        },
      },
    })

    return trendingMovies.map((movie) => ({
      ...movie,
      genres: movie.genres.map((mg) => mg.genre.name),
    }))
  }

  async getRecommendations(userId: string, limit = 20) {
    // This is a simplified recommendation logic
    // In a real application, you would have a more sophisticated algorithm

    // Get user's watched movies
    const watchedMovies = await this.prisma.watchedMovie.findMany({
      where: { userId },
      include: {
        movie: {
          include: {
            genres: {
              include: {
                genre: true,
              },
            },
          },
        },
      },
    })

    // If user hasn't watched any movies, return trending movies
    if (watchedMovies.length === 0) {
      return this.getTrendingMovies({ limit })
    }

    // Get genre IDs from watched movies
    const genreIds = new Set<string>()
    watchedMovies.forEach((wm) => {
      wm.movie.genres.forEach((g) => {
        genreIds.add(g.genreId)
      })
    })

    // Get movie IDs the user has already watched
    const watchedMovieIds = watchedMovies.map((wm) => wm.movieId)

    // Find movies with similar genres, but not already watched
    const recommendedMovies = await this.prisma.movie.findMany({
      where: {
        id: { notIn: watchedMovieIds },
        genres: {
          some: {
            genreId: { in: Array.from(genreIds) },
          },
        },
      },
      include: {
        genres: {
          include: {
            genre: true,
          },
        },
      },
      take: limit,
    })

    return recommendedMovies.map((movie) => ({
      ...movie,
      genres: movie.genres.map((mg) => mg.genre.name),
    }))
  }

  async markAsWatched(userId: string, movieId: string) {
    // Check if movie exists
    const movie = await this.prisma.movie.findUnique({
      where: { id: movieId },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${movieId} not found`)
    }

    // Check if already in watched list
    const existingEntry = await this.prisma.watchedMovie.findUnique({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    if (existingEntry) {
      return { message: "Movie already marked as watched" }
    }

    // Add to watched list
    await this.prisma.watchedMovie.create({
      data: {
        userId,
        movieId,
      },
    })

    return { message: "Movie marked as watched successfully" }
  }

  async removeFromWatched(userId: string, movieId: string) {
    // Check if movie exists
    const movie = await this.prisma.movie.findUnique({
      where: { id: movieId },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${movieId} not found`)
    }

    // Check if in watched list
    const existingEntry = await this.prisma.watchedMovie.findUnique({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    if (!existingEntry) {
      throw new BadRequestException("Movie is not in watched list")
    }

    // Remove from watched list
    await this.prisma.watchedMovie.delete({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    return { message: "Movie removed from watched list successfully" }
  }

  async addToFavorites(userId: string, movieId: string) {
    // Check if movie exists
    const movie = await this.prisma.movie.findUnique({
      where: { id: movieId },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${movieId} not found`)
    }

    // Check if already in favorites
    const existingEntry = await this.prisma.favoriteMovie.findUnique({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    if (existingEntry) {
      return { message: "Movie already in favorites" }
    }

    // Add to favorites
    await this.prisma.favoriteMovie.create({
      data: {
        userId,
        movieId,
      },
    })

    return { message: "Movie added to favorites successfully" }
  }

  async removeFromFavorites(userId: string, movieId: string) {
    // Check if movie exists
    const movie = await this.prisma.movie.findUnique({
      where: { id: movieId },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${movieId} not found`)
    }

    // Check if in favorites
    const existingEntry = await this.prisma.favoriteMovie.findUnique({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    if (!existingEntry) {
      throw new BadRequestException("Movie is not in favorites")
    }

    // Remove from favorites
    await this.prisma.favoriteMovie.delete({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    return { message: "Movie removed from favorites successfully" }
  }

  async addToWatchLater(userId: string, movieId: string) {
    // Check if movie exists
    const movie = await this.prisma.movie.findUnique({
      where: { id: movieId },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${movieId} not found`)
    }

    // Check if already in watch later
    const existingEntry = await this.prisma.watchLaterMovie.findUnique({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    if (existingEntry) {
      return { message: "Movie already in watch later list" }
    }

    // Add to watch later
    await this.prisma.watchLaterMovie.create({
      data: {
        userId,
        movieId,
      },
    })

    return { message: "Movie added to watch later list successfully" }
  }

  async removeFromWatchLater(userId: string, movieId: string) {
    // Check if movie exists
    const movie = await this.prisma.movie.findUnique({
      where: { id: movieId },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${movieId} not found`)
    }

    // Check if in watch later
    const existingEntry = await this.prisma.watchLaterMovie.findUnique({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    if (!existingEntry) {
      throw new BadRequestException("Movie is not in watch later list")
    }

    // Remove from watch later
    await this.prisma.watchLaterMovie.delete({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    return { message: "Movie removed from watch later list successfully" }
  }

  async getUserWatchedMovies(userId: string, query: { page?: number; limit?: number }) {
    const { page = 1, limit = 20 } = query
    const skip = (page - 1) * limit

    const [watchedMovies, totalCount] = await Promise.all([
      this.prisma.watchedMovie.findMany({
        where: { userId },
        orderBy: { watchedAt: "desc" },
        skip,
        take: limit,
        include: {
          movie: {
            include: {
              genres: {
                include: {
                  genre: true,
                },
              },
            },
          },
        },
      }),
      this.prisma.watchedMovie.count({ where: { userId } }),
    ])

    return {
      data: watchedMovies.map((wm) => ({
        ...wm.movie,
        watchedAt: wm.watchedAt,
        genres: wm.movie.genres.map((mg) => mg.genre.name),
      })),
      meta: {
        current_page: page,
        per_page: limit,
        total_count: totalCount,
        total_pages: Math.ceil(totalCount / limit),
      },
    }
  }

  async getUserFavoriteMovies(userId: string, query: { page?: number; limit?: number }) {
    const { page = 1, limit = 20 } = query
    const skip = (page - 1) * limit

    const [favoriteMovies, totalCount] = await Promise.all([
      this.prisma.favoriteMovie.findMany({
        where: { userId },
        orderBy: { favoriteAt: "desc" },
        skip,
        take: limit,
        include: {
          movie: {
            include: {
              genres: {
                include: {
                  genre: true,
                },
              },
            },
          },
        },
      }),
      this.prisma.favoriteMovie.count({ where: { userId } }),
    ])

    return {
      data: favoriteMovies.map((fm) => ({
        ...fm.movie,
        favoriteAt: fm.favoriteAt,
        genres: fm.movie.genres.map((mg) => mg.genre.name),
      })),
      meta: {
        current_page: page,
        per_page: limit,
        total_count: totalCount,
        total_pages: Math.ceil(totalCount / limit),
      },
    }
  }

  async getUserWatchLaterMovies(userId: string, query: { page?: number; limit?: number }) {
    const { page = 1, limit = 20 } = query
    const skip = (page - 1) * limit

    const [watchLaterMovies, totalCount] = await Promise.all([
      this.prisma.watchLaterMovie.findMany({
        where: { userId },
        orderBy: { addedAt: "desc" },
        skip,
        take: limit,
        include: {
          movie: {
            include: {
              genres: {
                include: {
                  genre: true,
                },
              },
            },
          },
        },
      }),
      this.prisma.watchLaterMovie.count({ where: { userId } }),
    ])

    return {
      data: watchLaterMovies.map((wlm) => ({
        ...wlm.movie,
        addedAt: wlm.addedAt,
        genres: wlm.movie.genres.map((mg) => mg.genre.name),
      })),
      meta: {
        current_page: page,
        per_page: limit,
        total_count: totalCount,
        total_pages: Math.ceil(totalCount / limit),
      },
    }
  }
}

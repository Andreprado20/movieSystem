import { Injectable, NotFoundException, BadRequestException } from "@nestjs/common"
import type { PrismaService } from "../prisma/prisma.service"
import type { CreateReviewDto } from "./dto/create-review.dto"
import type { UpdateReviewDto } from "./dto/update-review.dto"
import type { CreateCommentDto } from "./dto/create-comment.dto"
import type { UpdateCommentDto } from "./dto/update-comment.dto"

@Injectable()
export class ReviewsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(userId: string, movieId: string, createReviewDto: CreateReviewDto) {
    // Check if movie exists
    const movie = await this.prisma.movie.findUnique({
      where: { id: movieId },
    })

    if (!movie) {
      throw new NotFoundException(`Movie with ID ${movieId} not found`)
    }

    // Check if user has already reviewed this movie
    const existingReview = await this.prisma.review.findUnique({
      where: {
        userId_movieId: {
          userId,
          movieId,
        },
      },
    })

    if (existingReview) {
      throw new BadRequestException("You have already reviewed this movie")
    }

    // Create the review
    const review = await this.prisma.review.create({
      data: {
        content: createReviewDto.content,
        rating: createReviewDto.rating,
        userId,
        movieId,
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            name: true,
            avatar: true,
          },
        },
        _count: {
          select: {
            likes: true,
            comments: true,
          },
        },
      },
    })

    return {
      ...review,
      likesCount: review._count.likes,
      commentsCount: review._count.comments,
      _count: undefined,
    }
  }

  async update(userId: string, movieId: string, reviewId: string, updateReviewDto: UpdateReviewDto) {
    // Check if review exists and belongs to user
    const review = await this.prisma.review.findUnique({
      where: { id: reviewId },
    })

    if (!review) {
      throw new NotFoundException(`Review with ID ${reviewId} not found`)
    }

    if (review.userId !== userId) {
      throw new BadRequestException("You can only update your own reviews")
    }

    // Update the review
    const updatedReview = await this.prisma.review.update({
      where: { id: reviewId },
      data: {
        content: updateReviewDto.content,
        rating: updateReviewDto.rating,
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            name: true,
            avatar: true,
          },
        },
        _count: {
          select: {
            likes: true,
            comments: true,
          },
        },
      },
    })

    return {
      ...updatedReview,
      likesCount: updatedReview._count.likes,
      commentsCount: updatedReview._count.comments,
      _count: undefined,
    }
  }

  async remove(userId: string, movieId: string, reviewId: string) {
    // Check if review exists and belongs to user
    const review = await this.prisma.review.findUnique({
      where: { id: reviewId },
    })

    if (!review) {
      throw new NotFoundException(`Review with ID ${reviewId} not found`)
    }

    if (review.userId !== userId) {
      throw new BadRequestException("You can only delete your own reviews")
    }

    // Delete the review
    await this.prisma.review.delete({
      where: { id: reviewId },
    })

    return { message: "Review deleted successfully" }
  }

  async likeReview(userId: string, reviewId: string) {
    // Check if review exists
    const review = await this.prisma.review.findUnique({
      where: { id: reviewId },
    })

    if (!review) {
      throw new NotFoundException(`Review with ID ${reviewId} not found`)
    }

    // Check if user has already liked this review
    const existingLike = await this.prisma.reviewLike.findUnique({
      where: {
        userId_reviewId: {
          userId,
          reviewId,
        },
      },
    })

    if (existingLike) {
      return { message: "You have already liked this review" }
    }

    // Create the like
    await this.prisma.reviewLike.create({
      data: {
        userId,
        reviewId,
      },
    })

    // Get the updated like count
    const likeCount = await this.prisma.reviewLike.count({
      where: { reviewId },
    })

    return { likesCount: likeCount }
  }

  async unlikeReview(userId: string, reviewId: string) {
    // Check if review exists
    const review = await this.prisma.review.findUnique({
      where: { id: reviewId },
    })

    if (!review) {
      throw new NotFoundException(`Review with ID ${reviewId} not found`)
    }

    // Check if user has liked this review
    const existingLike = await this.prisma.reviewLike.findUnique({
      where: {
        userId_reviewId: {
          userId,
          reviewId,
        },
      },
    })

    if (!existingLike) {
      throw new BadRequestException("You have not liked this review")
    }

    // Delete the like
    await this.prisma.reviewLike.delete({
      where: {
        userId_reviewId: {
          userId,
          reviewId,
        },
      },
    })

    // Get the updated like count
    const likeCount = await this.prisma.reviewLike.count({
      where: { reviewId },
    })

    return { likesCount: likeCount }
  }

  async createComment(userId: string, reviewId: string, createCommentDto: CreateCommentDto) {
    // Check if review exists
    const review = await this.prisma.review.findUnique({
      where: { id: reviewId },
    })

    if (!review) {
      throw new NotFoundException(`Review with ID ${reviewId} not found`)
    }

    // Create the comment
    const comment = await this.prisma.comment.create({
      data: {
        content: createCommentDto.content,
        userId,
        reviewId,
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            name: true,
            avatar: true,
          },
        },
      },
    })

    return comment
  }

  async updateComment(userId: string, reviewId: string, commentId: string, updateCommentDto: UpdateCommentDto) {
    // Check if comment exists and belongs to user
    const comment = await this.prisma.comment.findUnique({
      where: { id: commentId },
    })

    if (!comment) {
      throw new NotFoundException(`Comment with ID ${commentId} not found`)
    }

    if (comment.userId !== userId) {
      throw new BadRequestException("You can only update your own comments")
    }

    // Update the comment
    const updatedComment = await this.prisma.comment.update({
      where: { id: commentId },
      data: {
        content: updateCommentDto.content,
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            name: true,
            avatar: true,
          },
        },
      },
    })

    return updatedComment
  }

  async removeComment(userId: string, reviewId: string, commentId: string) {
    // Check if comment exists and belongs to user
    const comment = await this.prisma.comment.findUnique({
      where: { id: commentId },
    })

    if (!comment) {
      throw new NotFoundException(`Comment with ID ${commentId} not found`)
    }

    if (comment.userId !== userId) {
      throw new BadRequestException("You can only delete your own comments")
    }

    // Delete the comment
    await this.prisma.comment.delete({
      where: { id: commentId },
    })

    return { message: "Comment deleted successfully" }
  }

  async getComments(reviewId: string, query: { page?: number; limit?: number }) {
    const { page = 1, limit = 20 } = query
    const skip = (page - 1) * limit

    // Check if review exists
    const review = await this.prisma.review.findUnique({
      where: { id: reviewId },
    })

    if (!review) {
      throw new NotFoundException(`Review with ID ${reviewId} not found`)
    }

    const [comments, totalCount] = await Promise.all([
      this.prisma.comment.findMany({
        where: { reviewId },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
        include: {
          user: {
            select: {
              id: true,
              username: true,
              name: true,
              avatar: true,
            },
          },
        },
      }),
      this.prisma.comment.count({ where: { reviewId } }),
    ])

    return {
      data: comments,
      meta: {
        current_page: page,
        per_page: limit,
        total_count: totalCount,
        total_pages: Math.ceil(totalCount / limit),
      },
    }
  }
}

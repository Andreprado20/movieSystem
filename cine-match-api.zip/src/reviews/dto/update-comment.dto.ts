import { IsString, IsNotEmpty } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class UpdateCommentDto {
  @ApiProperty({
    example: "I agree with your review!",
    description: "The content of the comment",
  })
  @IsString()
  @IsNotEmpty()
  content: string
}

import { IsString, IsInt, Min, Max, IsOptional } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateReviewDto {
  @ApiProperty({
    example: "This movie was amazing!",
    description: "The content of the review",
    required: false,
  })
  @IsString()
  @IsOptional()
  content?: string

  @ApiProperty({
    example: 5,
    description: "The rating for the movie (1-10)",
  })
  @IsInt()
  @Min(1)
  @Max(10)
  rating: number
}

import { Controller, Get, Post, Body, Param, Delete, UseGuards, Req, Put, Query } from "@nestjs/common"
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam } from "@nestjs/swagger"
import type { ReviewsService } from "./reviews.service"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import type { CreateReviewDto } from "./dto/create-review.dto"
import type { UpdateReviewDto } from "./dto/update-review.dto"
import type { CreateCommentDto } from "./dto/create-comment.dto"
import type { UpdateCommentDto } from "./dto/update-comment.dto"
import type { Request } from "express"

@ApiTags("reviews")
@Controller()
export class ReviewsController {
  constructor(private readonly reviewsService: ReviewsService) {}

  @Post("filmes/:id/reviews")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "id", description: "Movie ID" })
  @ApiOperation({ summary: "Create movie review" })
  @ApiResponse({ status: 201, description: "Review created successfully." })
  @ApiResponse({ status: 400, description: "Bad request." })
  @ApiResponse({ status: 404, description: "Movie not found." })
  create(@Req() req: Request, @Param('id') movieId: string, @Body() createReviewDto: CreateReviewDto) {
    return this.reviewsService.create(req.user["id"], movieId, createReviewDto)
  }

  @Put("filmess/:id/reviews/:reviewId")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "id", description: "Movie ID" })
  @ApiParam({ name: "reviewId", description: "Review ID" })
  @ApiOperation({ summary: "Update movie review" })
  @ApiResponse({ status: 200, description: "Review updated successfully." })
  @ApiResponse({ status: 400, description: "Bad request." })
  @ApiResponse({ status: 404, description: "Review not found." })
  update(
    @Req() req: Request,
    @Param('id') movieId: string,
    @Param('reviewId') reviewId: string,
    @Body() updateReviewDto: UpdateReviewDto,
  ) {
    return this.reviewsService.update(req.user["id"], movieId, reviewId, updateReviewDto)
  }

  @Delete("filmes/:id/reviews/:reviewId")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "id", description: "Movie ID" })
  @ApiParam({ name: "reviewId", description: "Review ID" })
  @ApiOperation({ summary: "Delete movie review" })
  @ApiResponse({ status: 200, description: "Review deleted successfully." })
  @ApiResponse({ status: 400, description: "Bad request." })
  @ApiResponse({ status: 404, description: "Review not found." })
  remove(@Req() req: Request, @Param('id') movieId: string, @Param('reviewId') reviewId: string) {
    return this.reviewsService.remove(req.user["id"], movieId, reviewId)
  }

  @Post("reviews/:id/likes")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "id", description: "Review ID" })
  @ApiOperation({ summary: "Like a review" })
  @ApiResponse({ status: 200, description: "Review liked successfully." })
  @ApiResponse({ status: 404, description: "Review not found." })
  likeReview(@Req() req: Request, @Param('id') reviewId: string) {
    return this.reviewsService.likeReview(req.user["id"], reviewId)
  }

  @Delete("reviews/:id/likes")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "id", description: "Review ID" })
  @ApiOperation({ summary: "Unlike a review" })
  @ApiResponse({ status: 200, description: "Review unliked successfully." })
  @ApiResponse({ status: 400, description: "Bad request." })
  @ApiResponse({ status: 404, description: "Review not found." })
  unlikeReview(@Req() req: Request, @Param('id') reviewId: string) {
    return this.reviewsService.unlikeReview(req.user["id"], reviewId)
  }

  @Post("reviews/:id/comments")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "id", description: "Review ID" })
  @ApiOperation({ summary: "Comment on a review" })
  @ApiResponse({ status: 201, description: "Comment created successfully." })
  @ApiResponse({ status: 404, description: "Review not found." })
  createComment(@Req() req: Request, @Param('id') reviewId: string, @Body() createCommentDto: CreateCommentDto) {
    return this.reviewsService.createComment(req.user["id"], reviewId, createCommentDto)
  }

  @Put("reviews/:id/comments/:commentId")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "id", description: "Review ID" })
  @ApiParam({ name: "commentId", description: "Comment ID" })
  @ApiOperation({ summary: "Update comment" })
  @ApiResponse({ status: 200, description: "Comment updated successfully." })
  @ApiResponse({ status: 400, description: "Bad request." })
  @ApiResponse({ status: 404, description: "Comment not found." })
  updateComment(
    @Req() req: Request,
    @Param('id') reviewId: string,
    @Param('commentId') commentId: string,
    @Body() updateCommentDto: UpdateCommentDto,
  ) {
    return this.reviewsService.updateComment(req.user["id"], reviewId, commentId, updateCommentDto)
  }

  @Delete("reviews/:id/comments/:commentId")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiParam({ name: "id", description: "Review ID" })
  @ApiParam({ name: "commentId", description: "Comment ID" })
  @ApiOperation({ summary: "Delete comment" })
  @ApiResponse({ status: 200, description: "Comment deleted successfully." })
  @ApiResponse({ status: 400, description: "Bad request." })
  @ApiResponse({ status: 404, description: "Comment not found." })
  removeComment(@Req() req: Request, @Param('id') reviewId: string, @Param('commentId') commentId: string) {
    return this.reviewsService.removeComment(req.user["id"], reviewId, commentId)
  }

  @Get("reviews/:id/comments")
  @ApiParam({ name: "id", description: "Review ID" })
  @ApiOperation({ summary: "Get comments on review" })
  @ApiResponse({ status: 200, description: "Return a list of comments." })
  @ApiResponse({ status: 404, description: "Review not found." })
  getComments(@Param('id') reviewId: string, @Query('page') page?: number, @Query('limit') limit?: number) {
    return this.reviewsService.getComments(reviewId, { page, limit })
  }
}

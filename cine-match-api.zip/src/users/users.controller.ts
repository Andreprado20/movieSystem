import {
  Controller,
  Get,
  Put,
  Delete,
  Param,
  Body,
  UseGuards,
  Req,
  UseInterceptors,
  UploadedFile,
} from "@nestjs/common"
import { FileInterceptor } from "@nestjs/platform-express"
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam } from "@nestjs/swagger"
import type { UsersService } from "./users.service"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import type { UpdateUserDto } from "./dto/update-user.dto"
import type { UpdatePasswordDto } from "./dto/update-password.dto"
import type { DeleteUserDto } from "./dto/delete-user.dto"
import type { UpdateNotificationSettingsDto } from "./dto/update-notification-settings.dto"
import type { UpdatePrivacySettingsDto } from "./dto/update-privacy-settings.dto"
import type { Request } from "express"
import type { Express } from "express"

@ApiTags("users")
@Controller("users")
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get('me')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get current user profile' })
  @ApiResponse({ status: 200, description: 'Return the current user profile.' })
  getProfile(@Req() req: Request) {
    return this.usersService.findOne(req.user['id']);
  }

  @Put("me")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: "Update user profile" })
  @ApiResponse({ status: 200, description: "Return the updated user profile." })
  updateProfile(@Req() req: Request, @Body() updateUserDto: UpdateUserDto) {
    return this.usersService.update(req.user["id"], updateUserDto)
  }

  @Put("me/password")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: "Change password" })
  @ApiResponse({ status: 200, description: "Password changed successfully." })
  updatePassword(@Req() req: Request, @Body() updatePasswordDto: UpdatePasswordDto) {
    return this.usersService.updatePassword(req.user["id"], updatePasswordDto)
  }

  @Delete("me")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: "Delete user account" })
  @ApiResponse({ status: 200, description: "User account deleted successfully." })
  removeAccount(@Req() req: Request, @Body() deleteUserDto: DeleteUserDto) {
    return this.usersService.remove(req.user["id"], deleteUserDto.password)
  }

  @Put("me/avatar")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @UseInterceptors(FileInterceptor("avatar"))
  @ApiOperation({ summary: "Update profile picture" })
  @ApiResponse({ status: 200, description: "Profile picture updated successfully." })
  updateAvatar(@Req() req: Request, @UploadedFile() file: Express.Multer.File) {
    return this.usersService.updateAvatar(req.user["id"], file)
  }

  @Put("me/settings/notifications")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: "Update notification settings" })
  @ApiResponse({ status: 200, description: "Notification settings updated successfully." })
  updateNotificationSettings(
    @Req() req: Request,
    @Body() updateNotificationSettingsDto: UpdateNotificationSettingsDto,
  ) {
    return this.usersService.updateNotificationSettings(req.user["id"], updateNotificationSettingsDto)
  }

  @Put("me/settings/privacy")
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: "Update privacy settings" })
  @ApiResponse({ status: 200, description: "Privacy settings updated successfully." })
  updatePrivacySettings(@Req() req: Request, @Body() updatePrivacySettingsDto: UpdatePrivacySettingsDto) {
    return this.usersService.updatePrivacySettings(req.user["id"], updatePrivacySettingsDto)
  }

  @Get(':id')
  @ApiParam({ name: 'id', description: 'User ID' })
  @ApiOperation({ summary: 'Get user profile by ID' })
  @ApiResponse({ status: 200, description: 'Return the user profile.' })
  @ApiResponse({ status: 404, description: 'User not found.' })
  getUserById(@Param('id') id: string) {
    return this.usersService.findOne(id);
  }

  @Get('username/:username')
  @ApiParam({ name: 'username', description: 'Username' })
  @ApiOperation({ summary: 'Get user profile by username' })
  @ApiResponse({ status: 200, description: 'Return the user profile.' })
  @ApiResponse({ status: 404, description: 'User not found.' })
  getUserByUsername(@Param('username') username: string) {
    return this.usersService.findByUsername(username);
  }

  @Get(':id/stats')
  @ApiParam({ name: 'id', description: 'User ID' })
  @ApiOperation({ summary: 'Get user statistics' })
  @ApiResponse({ status: 200, description: 'Return the user statistics.' })
  @ApiResponse({ status: 404, description: 'User not found.' })
  getUserStats(@Param('id') id: string) {
    return this.usersService.getUserStats(id);
  }
}

import { IsBoolean, IsOptional } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class UpdateNotificationSettingsDto {
  @ApiProperty({
    example: true,
    description: "Enable follow notifications",
    required: false,
  })
  @IsBoolean()
  @IsOptional()
  followNotification?: boolean

  @ApiProperty({
    example: true,
    description: "Enable message notifications",
    required: false,
  })
  @IsBoolean()
  @IsOptional()
  messageNotification?: boolean

  @ApiProperty({
    example: true,
    description: "Enable review notifications",
    required: false,
  })
  @IsBoolean()
  @IsOptional()
  reviewNotification?: boolean

  @ApiProperty({
    example: true,
    description: "Enable event notifications",
    required: false,
  })
  @IsBoolean()
  @IsOptional()
  eventNotification?: boolean
}

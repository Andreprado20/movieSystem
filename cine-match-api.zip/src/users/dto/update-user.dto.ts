import { IsEmail, IsString, IsOptional } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class UpdateUserDto {
  @ApiProperty({
    example: "john.doe@example.com",
    description: "The email of the user",
    required: false,
  })
  @IsEmail()
  @IsOptional()
  email?: string

  @ApiProperty({
    example: "johndoe",
    description: "The username of the user",
    required: false,
  })
  @IsString()
  @IsOptional()
  username?: string

  @ApiProperty({
    example: "John Doe",
    description: "The full name of the user",
    required: false,
  })
  @IsString()
  @IsOptional()
  name?: string

  @ApiProperty({
    example: "I love movies!",
    description: "The bio of the user",
    required: false,
  })
  @IsString()
  @IsOptional()
  bio?: string
}

import { IsBoolean, IsOptional } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class UpdatePrivacySettingsDto {
  @ApiProperty({
    example: true,
    description: "Make profile public",
    required: false,
  })
  @IsBoolean()
  @IsOptional()
  publicProfile?: boolean

  @ApiProperty({
    example: true,
    description: "Make watch list public",
    required: false,
  })
  @IsBoolean()
  @IsOptional()
  publicWatchlist?: boolean

  @ApiProperty({
    example: true,
    description: "Make favorites public",
    required: false,
  })
  @IsBoolean()
  @IsOptional()
  publicFavorites?: boolean
}

import { IsString, IsNotEmpty } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class DeleteUserDto {
  @ApiProperty({
    example: "password123",
    description: "Password to confirm account deletion",
  })
  @IsString()
  @IsNotEmpty()
  password: string
}

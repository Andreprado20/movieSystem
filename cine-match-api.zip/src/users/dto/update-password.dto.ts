import { IsString, MinLength, IsNotEmpty } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class UpdatePasswordDto {
  @ApiProperty({
    example: "currentPassword123",
    description: "Current password",
  })
  @IsString()
  @IsNotEmpty()
  currentPassword: string

  @ApiProperty({
    example: "newPassword123",
    description: "New password",
  })
  @IsString()
  @MinLength(8)
  @IsNotEmpty()
  newPassword: string
}

import { Injectable, NotFoundException, BadRequestException } from "@nestjs/common"
import type { PrismaService } from "../prisma/prisma.service"
import type { UpdateUserDto } from "./dto/update-user.dto"
import type { UpdatePasswordDto } from "./dto/update-password.dto"
import type { UpdateNotificationSettingsDto } from "./dto/update-notification-settings.dto"
import type { UpdatePrivacySettingsDto } from "./dto/update-privacy-settings.dto"
import * as bcrypt from "bcrypt"
import type { Express } from "express"

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  async findOne(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        username: true,
        name: true,
        birthDate: true,
        bio: true,
        avatar: true,
        createdAt: true,
        updatedAt: true,
      },
    })

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`)
    }

    return user
  }

  async findByUsername(username: string) {
    const user = await this.prisma.user.findUnique({
      where: { username },
      select: {
        id: true,
        username: true,
        name: true,
        bio: true,
        avatar: true,
        createdAt: true,
      },
    })

    if (!user) {
      throw new NotFoundException(`User with username ${username} not found`)
    }

    return user
  }

  async update(id: string, updateUserDto: UpdateUserDto) {
    // Check if email or username is taken
    if (updateUserDto.email) {
      const existingUserByEmail = await this.prisma.user.findUnique({
        where: { email: updateUserDto.email },
      })

      if (existingUserByEmail && existingUserByEmail.id !== id) {
        throw new BadRequestException("Email already in use")
      }
    }

    if (updateUserDto.username) {
      const existingUserByUsername = await this.prisma.user.findUnique({
        where: { username: updateUserDto.username },
      })

      if (existingUserByUsername && existingUserByUsername.id !== id) {
        throw new BadRequestException("Username already in use")
      }
    }

    const user = await this.prisma.user.update({
      where: { id },
      data: updateUserDto,
      select: {
        id: true,
        email: true,
        username: true,
        name: true,
        birthDate: true,
        bio: true,
        avatar: true,
        createdAt: true,
        updatedAt: true,
      },
    })

    return user
  }

  async updatePassword(id: string, updatePasswordDto: UpdatePasswordDto) {
    // Get the user to validate the current password
    const user = await this.prisma.user.findUnique({
      where: { id },
    })

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`)
    }

    // Verify current password
    const isPasswordValid = await bcrypt.compare(updatePasswordDto.currentPassword, user.password)

    if (!isPasswordValid) {
      throw new BadRequestException("Current password is incorrect")
    }

    // Hash the new password
    const hashedPassword = await this.hashPassword(updatePasswordDto.newPassword)

    // Update the password
    await this.prisma.user.update({
      where: { id },
      data: {
        password: hashedPassword,
      },
    })

    return { message: "Password updated successfully" }
  }

  async remove(id: string, password: string) {
    // Get the user to validate the password
    const user = await this.prisma.user.findUnique({
      where: { id },
    })

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`)
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password)

    if (!isPasswordValid) {
      throw new BadRequestException("Password is incorrect")
    }

    // Delete the user
    await this.prisma.user.delete({
      where: { id },
    })

    return { message: "User deleted successfully" }
  }

  async updateAvatar(id: string, file: Express.Multer.File) {
    // In a real application, you would upload the image to a storage service
    // For now, we'll just update the avatar field with a dummy URL
    const avatarUrl = `https://example.com/avatars/${id}-${Date.now()}.jpg`

    const user = await this.prisma.user.update({
      where: { id },
      data: {
        avatar: avatarUrl,
      },
      select: {
        id: true,
        avatar: true,
      },
    })

    return user
  }

  async updateNotificationSettings(userId: string, updateNotificationSettingsDto: UpdateNotificationSettingsDto) {
    const settings = await this.prisma.notificationSettings.update({
      where: { userId },
      data: updateNotificationSettingsDto,
    })

    return settings
  }

  async updatePrivacySettings(userId: string, updatePrivacySettingsDto: UpdatePrivacySettingsDto) {
    const settings = await this.prisma.privacySettings.update({
      where: { userId },
      data: updatePrivacySettingsDto,
    })

    return settings
  }

  async getUserStats(userId: string) {
    // Get user stats
    const watchedCount = await this.prisma.watchedMovie.count({
      where: { userId },
    })

    const reviewsCount = await this.prisma.review.count({
      where: { userId },
    })

    const favoritesCount = await this.prisma.favoriteMovie.count({
      where: { userId },
    })

    const followersCount = await this.prisma.follow.count({
      where: { followingId: userId },
    })

    const followingCount = await this.prisma.follow.count({
      where: { followerId: userId },
    })

    return {
      watchedCount,
      reviewsCount,
      favoritesCount,
      followersCount,
      followingCount,
    }
  }

  private async hashPassword(password: string) {
    const saltRounds = 10
    return bcrypt.hash(password, saltRounds)
  }
}

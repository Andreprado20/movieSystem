import { Injectable, UnauthorizedException, BadRequestException } from "@nestjs/common"
import type { JwtService } from "@nestjs/jwt"
import type { PrismaService } from "../prisma/prisma.service"
import type { UsersService } from "../users/users.service"
import type { RegisterDto } from "./dto/register.dto"
import type { LoginDto } from "./dto/login.dto"
import type { ResetPasswordDto } from "./dto/reset-password.dto"
import type { ForgotPasswordDto } from "./dto/forgot-password.dto"
import * as bcrypt from "bcrypt"

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
  ) {}

  async register(registerDto: RegisterDto) {
    // Check if user already exists
    const existingUserByEmail = await this.prisma.user.findUnique({
      where: { email: registerDto.email },
    })

    if (existingUserByEmail) {
      throw new BadRequestException("Email already in use")
    }

    const existingUserByUsername = await this.prisma.user.findUnique({
      where: { username: registerDto.username },
    })

    if (existingUserByUsername) {
      throw new BadRequestException("Username already in use")
    }

    // Hash password
    const hashedPassword = await this.hashPassword(registerDto.password)

    // Create user
    const user = await this.prisma.user.create({
      data: {
        email: registerDto.email,
        username: registerDto.username,
        name: registerDto.name,
        password: hashedPassword,
        birthDate: registerDto.birthDate,
        notificationSettings: {
          create: {},
        },
        privacySettings: {
          create: {},
        },
      },
    })

    // Generate token
    const token = this.generateToken(user.id)

    // Return user without password and with token
    const { password, ...userWithoutPassword } = user
    return {
      ...userWithoutPassword,
      token,
    }
  }

  async login(loginDto: LoginDto) {
    // Find user by email
    const user = await this.prisma.user.findUnique({
      where: { email: loginDto.email },
    })

    if (!user) {
      throw new UnauthorizedException("Invalid credentials")
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(loginDto.password, user.password)

    if (!isPasswordValid) {
      throw new UnauthorizedException("Invalid credentials")
    }

    // Generate token
    const token = this.generateToken(user.id)

    // Return user without password and with token
    const { password, ...userWithoutPassword } = user
    return {
      ...userWithoutPassword,
      token,
    }
  }

  async forgotPassword(forgotPasswordDto: ForgotPasswordDto) {
    const user = await this.prisma.user.findUnique({
      where: { email: forgotPasswordDto.email },
    })

    if (!user) {
      // We don't want to reveal that the email doesn't exist
      return { message: "If your email is registered, you will receive a password reset link" }
    }

    // In a real app, you would generate a reset token and send an email
    // For now, we'll just return a success message
    return { message: "If your email is registered, you will receive a password reset link" }
  }

  async resetPassword(resetPasswordDto: ResetPasswordDto) {
    // In a real app, you would validate the reset token
    // For now, we'll just pretend the token is valid and reset the password

    // Hash the new password
    const hashedPassword = await this.hashPassword(resetPasswordDto.newPassword)

    // Update the user's password
    // In a real app, you would find the user by the reset token
    // Here, we'll just simulate success
    return { message: "Password reset successfully" }
  }

  async validateUser(email: string, password: string) {
    const user = await this.prisma.user.findUnique({
      where: { email },
    })

    if (!user) {
      return null
    }

    const isPasswordValid = await bcrypt.compare(password, user.password)

    if (!isPasswordValid) {
      return null
    }

    const { password: _, ...result } = user
    return result
  }

  private generateToken(userId: string) {
    const payload = { sub: userId }
    return this.jwtService.sign(payload)
  }

  private async hashPassword(password: string) {
    const saltRounds = 10
    return bcrypt.hash(password, saltRounds)
  }
}

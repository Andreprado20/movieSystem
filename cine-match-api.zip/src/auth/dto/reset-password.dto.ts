import { IsString, IsNotEmpty, MinLength } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class ResetPasswordDto {
  @ApiProperty({
    example: "reset-token-123",
    description: "Password reset token",
  })
  @IsString()
  @IsNotEmpty()
  token: string

  @ApiProperty({
    example: "newPassword123",
    description: "New password",
  })
  @IsString()
  @MinLength(8)
  @IsNotEmpty()
  newPassword: string
}

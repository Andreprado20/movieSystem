import { IsEmail, IsString, MinLength, IsDateString, IsNotEmpty } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class RegisterDto {
  @ApiProperty({
    example: "john.doe@example.com",
    description: "The email of the user",
  })
  @IsEmail()
  @IsNotEmpty()
  email: string

  @ApiProperty({
    example: "johndoe",
    description: "The username of the user",
  })
  @IsString()
  @IsNotEmpty()
  username: string

  @ApiProperty({
    example: "John Doe",
    description: "The full name of the user",
  })
  @IsString()
  @IsNotEmpty()
  name: string

  @ApiProperty({
    example: "password123",
    description: "The password of the user",
  })
  @IsString()
  @MinLength(8)
  @IsNotEmpty()
  password: string

  @ApiProperty({
    example: "1990-01-01",
    description: "The birth date of the user",
  })
  @IsDateString()
  @IsNotEmpty()
  birthDate: Date
}

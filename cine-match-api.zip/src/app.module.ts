import { Module } from "@nestjs/common"
import { ConfigModule } from "@nestjs/config"
import { PrismaModule } from "./prisma/prisma.module"
import { AuthModule } from "./auth/auth.module"
import { UsersModule } from "./users/users.module"
import { MoviesModule } from "./movies/movies.module"
import { CommunitiesModule } from "./communities/communities.module"
import { ConversationsModule } from "./conversations/conversations.module"
import { EventsModule } from "./events/events.module"
import { NotificationsModule } from "./notifications/notifications.module"
import { ListsModule } from "./lists/lists.module"
import { SearchModule } from "./search/search.module"
import { ReviewsModule } from "./reviews/reviews.module"

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    AuthModule,
    UsersModule,
    MoviesModule,
    CommunitiesModule,
    ConversationsModule,
    EventsModule,
    NotificationsModule,
    ListsModule,
    SearchModule,
    ReviewsModule,
  ],
})
export class AppModule {}
